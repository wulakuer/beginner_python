from distutils.core import setup
setup(
name='nesterVV',
version='0.0.1',
py_modules=['nesterVV'],
author='vivian',
author_email='vivian@169.com',
url='http://www.baidu.com',
description='This is the first'
)