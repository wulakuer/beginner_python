from distutils.core import setup
setup(
name='nesterVV',
version='0.0.3',
py_modules=['nesterVV'],
author='vivian',
author_email='vivian@169.com',
url='http://www.baidu.com',
description='Add the flag to control is the indent is needed for you. Add default value for the indent number'
)